# Auto Clicker

Small utility program to automatically, sequentially simulate clicks of a series of user defined points on the screen.

![Screenshot](http://ryanharrison.co.uk/apps/autoclicker/Auto_Clicker.jpg)

Users can:

* Specify to simulate left/right clicks
* Specify the time to sleep after each click
* How many times to repeat the series of clicks

Hotkeys defined to easily add the current position of the cursor to the sequence.
